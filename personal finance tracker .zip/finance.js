let totalIncome = 0;
let totalExpenses = 0;

function addTransaction() {
    const description = document.getElementById("description").value;
    const amount = parseFloat(document.getElementById("amount").value);
    const type = document.getElementById("type").value;

    if (!description || isNaN(amount)) {
        alert("Please enter valid description and amount.");
        return;
    }

    const transactionList = document.getElementById("transaction-list");
    
    // Create a new list item
    const listItem = document.createElement("li");
    
    // Update totals and balance
    if (type === "income") {
        totalIncome += amount;
        listItem.textContent = `${description}: +$${amount.toFixed(2)}`;
    } else {
        totalExpenses += amount;
        listItem.textContent = `${description}: -$${amount.toFixed(2)}`;
    }

    transactionList.appendChild(listItem);
    
    // Update summary
    updateSummary();

    // Clear input fields
    document.getElementById("description").value = '';
    document.getElementById("amount").value = '';
}

function updateSummary() {
    document.getElementById("total-income").textContent = totalIncome.toFixed(2);
    document.getElementById("total-expenses").textContent = totalExpenses.toFixed(2);
    
    const balance = totalIncome - totalExpenses;
    document.getElementById("balance").textContent = balance.toFixed(2);
}
